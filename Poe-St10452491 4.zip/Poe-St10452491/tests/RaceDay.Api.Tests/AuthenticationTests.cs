using RaceDay.Api.Models; using RaceDay.Api.Services; using Xunit;
namespace RaceDay.Api.Tests;
public class AuthenticationTests{
 [Fact] public void SessionTokenPreservesRole(){var service=new TokenService();var session=service.Create(new User{Id=5,Role=UserRole.Organiser});Assert.Equal(UserRole.Organiser,service.Get(session.Token)!.Role);}
 [Fact] public void LogoutRevokesToken(){var service=new TokenService();var session=service.Create(new User{Id=1,Role=UserRole.Participant});service.Remove(session.Token);Assert.Null(service.Get(session.Token));}
 [Theory][InlineData("Pending")][InlineData("Confirmed")][InlineData("Cancelled")] public void SupportedEnrolmentStatusesParse(string value){Assert.True(Enum.TryParse<EnrolmentStatus>(value,true,out _));}
 [Fact] public void ParticipantCannotBeTreatedAsOrganiser(){var user=new User{Role=UserRole.Participant};Assert.NotEqual(UserRole.Organiser,user.Role);}
}
