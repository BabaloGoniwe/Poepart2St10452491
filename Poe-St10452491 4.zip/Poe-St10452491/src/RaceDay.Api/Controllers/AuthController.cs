using Microsoft.AspNetCore.Mvc; using Microsoft.EntityFrameworkCore; using RaceDay.Api.Data; using RaceDay.Api.Models; using RaceDay.Api.Services;
namespace RaceDay.Api.Controllers;
[ApiController][Route("api/auth")]
public class AuthController(RaceDayDbContext db,TokenService tokens):ControllerBase{
 public record RegisterRequest(string FullName,string Email,string Password,string Role);
 public record LoginRequest(string Email,string Password);
 [HttpPost("register")]
 public async Task<IActionResult> Register(RegisterRequest request){
  if(string.IsNullOrWhiteSpace(request.FullName)||string.IsNullOrWhiteSpace(request.Email)||string.IsNullOrWhiteSpace(request.Password)||request.Password.Length<8)return BadRequest("Full name, email and a password of at least 8 characters are required.");
  if(!Enum.TryParse<UserRole>(request.Role,true,out var role))return BadRequest("Role must be Organiser or Participant.");
  var email=request.Email.Trim().ToLowerInvariant();if(await db.Users.AnyAsync(x=>x.Email==email))return Conflict("Email already registered.");
  var user=new User{FullName=request.FullName.Trim(),Email=email,PasswordHash=BCrypt.Net.BCrypt.HashPassword(request.Password),Role=role,Profile=new Profile{Phone="",City=""}};db.Users.Add(user);await db.SaveChangesAsync();return Created($"api/profile/{user.Id}",new{user.Id,user.FullName,user.Email,user.Role});
 }
 [HttpPost("login")]
 public async Task<IActionResult> Login(LoginRequest request){var email=request.Email.Trim().ToLowerInvariant();var user=await db.Users.SingleOrDefaultAsync(x=>x.Email==email);if(user is null||!BCrypt.Net.BCrypt.Verify(request.Password,user.PasswordHash))return Unauthorized("Invalid email or password.");var session=tokens.Create(user);return Ok(new{token=session.Token,user=new{user.Id,user.FullName,user.Email,user.Role}});}
 [HttpPost("logout")]
 public IActionResult Logout([FromHeader(Name="X-Session-Token")]string? token){tokens.Remove(token);return NoContent();}
}
