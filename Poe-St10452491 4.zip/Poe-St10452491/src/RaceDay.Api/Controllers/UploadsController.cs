using Microsoft.AspNetCore.Mvc; using RaceDay.Api.Models; using RaceDay.Api.Services;
namespace RaceDay.Api.Controllers;
[ApiController][Route("api/uploads")]
public class UploadsController(IBlobStorageService storage,TokenService tokens) : ControllerBase {
 [HttpPost("event-image")] public async Task<IActionResult> Upload(IFormFile file,CancellationToken cancellationToken){var session=tokens.Get(Request.Headers["X-Session-Token"]);if(session is null)return Unauthorized();if(session.Role!=UserRole.Organiser)return Forbid();if(file.Length==0)return BadRequest("A non-empty image is required.");if(!file.ContentType.StartsWith("image/",StringComparison.OrdinalIgnoreCase))return BadRequest("Only image uploads are accepted.");await using var stream=file.OpenReadStream();var url=await storage.UploadAsync(stream,file.FileName,file.ContentType,cancellationToken);return Ok(new{url});}
}
