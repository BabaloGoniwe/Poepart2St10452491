using Azure.Storage.Blobs;
namespace RaceDay.Api.Services;
public interface IBlobStorageService { Task<string> UploadAsync(Stream content, string fileName, string contentType, CancellationToken cancellationToken = default); }
public sealed class BlobStorageService(IConfiguration configuration) : IBlobStorageService {
 public async Task<string> UploadAsync(Stream content, string fileName, string contentType, CancellationToken cancellationToken = default) {
  var connection = configuration["AzureStorage:ConnectionString"];
  if (string.IsNullOrWhiteSpace(connection)) throw new InvalidOperationException("AzureStorage:ConnectionString is not configured.");
  var container = new BlobContainerClient(connection, configuration["AzureStorage:ContainerName"] ?? "raceday-images");
  await container.CreateIfNotExistsAsync(cancellationToken: cancellationToken);
  var blob = container.GetBlobClient($"{Guid.NewGuid():N}-{Path.GetFileName(fileName)}");
  await blob.UploadAsync(content, overwrite: false, cancellationToken);
  return blob.Uri.ToString();
 }
}
