using System.Collections.Concurrent; using RaceDay.Api.Models;
namespace RaceDay.Api.Services;
public record SessionToken(string Token,int UserId,UserRole Role);
public class TokenService { readonly ConcurrentDictionary<string,SessionToken> sessions=[]; public SessionToken Create(User user){var s=new SessionToken(Guid.NewGuid().ToString("N"),user.Id,user.Role);sessions[s.Token]=s;return s;} public SessionToken? Get(string? token)=>token is not null&&sessions.TryGetValue(token,out var value)?value:null; public void Remove(string? token){if(token is not null)sessions.TryRemove(token,out _);} }
