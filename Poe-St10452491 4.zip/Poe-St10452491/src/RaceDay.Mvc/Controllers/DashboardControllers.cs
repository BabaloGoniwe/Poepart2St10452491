using Microsoft.AspNetCore.Mvc;
namespace RaceDay.Mvc.Controllers;
public class OrganiserController(IHttpContextAccessor context) : Controller { public IActionResult Index(){if(context.HttpContext!.Session.GetString("RaceDayRole")!="Organiser")return RedirectToAction("Login","Account");return View();} }
public class ParticipantController(IHttpContextAccessor context) : Controller { public IActionResult Index(){if(context.HttpContext!.Session.GetString("RaceDayRole")!="Participant")return RedirectToAction("Login","Account");return View();} }
