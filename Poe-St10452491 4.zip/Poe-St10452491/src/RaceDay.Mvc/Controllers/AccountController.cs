using System.Net.Http.Json; using Microsoft.AspNetCore.Mvc;
namespace RaceDay.Mvc.Controllers;
public class AccountController(IHttpClientFactory clients) : Controller {
 record LoginDto(string Email,string Password); record RegisterDto(string FullName,string Email,string Password,string Role);
 [HttpGet] public IActionResult Login()=>View();
 [HttpPost] public async Task<IActionResult> Login(string email,string password){var r=await clients.CreateClient("RaceDayApi").PostAsJsonAsync("api/auth/login",new LoginDto(email,password));if(!r.IsSuccessStatusCode){ViewBag.Error="Invalid email or password.";return View();}var data=await r.Content.ReadFromJsonAsync<LoginResponse>();HttpContext.Session.SetString("RaceDayToken",data!.Token);HttpContext.Session.SetString("RaceDayRole",data.User.Role);return RedirectToAction("Index",data.User.Role=="Organiser"?"Organiser":"Participant");}
 [HttpGet] public IActionResult Register()=>View();
 [HttpPost] public async Task<IActionResult> Register(string fullName,string email,string password,string role){var r=await clients.CreateClient("RaceDayApi").PostAsJsonAsync("api/auth/register",new RegisterDto(fullName,email,password,role));if(!r.IsSuccessStatusCode){ViewBag.Error=await r.Content.ReadAsStringAsync();return View();}return RedirectToAction(nameof(Login));}
 [HttpPost] public async Task<IActionResult> Logout(){var token=HttpContext.Session.GetString("RaceDayToken");if(token is not null){var req=new HttpRequestMessage(HttpMethod.Post,"api/auth/logout");req.Headers.Add("X-Session-Token",token);await clients.CreateClient("RaceDayApi").SendAsync(req);}HttpContext.Session.Clear();return RedirectToAction("Index","Home");}
 record LoginResponse(string Token,LoginUser User); record LoginUser(string Role);
}
