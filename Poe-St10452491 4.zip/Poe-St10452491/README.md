# RaceDay — Poe ST10452491

RaceDay is a role-based event management system for South African running, walking and cycling events. It contains an ASP.NET Core Web API, shared contracts, an MVC client, SQL Server EF Core Code First data access, Swagger, automated tests, and GitHub Actions CI/CD.

## Repository submission structure

The files below are committed directly in the repository, not only inside a ZIP:

```text
docs/
├── ERD.md
├── ERD.png
├── API-Endpoint-Plan.md
├── API-Endpoint-Plan.pdf
└── DatabaseScript.sql
src/
├── RaceDay.Api/
├── RaceDay.Contracts/
└── RaceDay.Mvc/
tests/RaceDay.Api.Tests/
.github/workflows/ci.yml
```

## User roles

### Organiser

Organisers can create, update and delete their own events, manage event categories, view enrolments for events they own, update enrolment statuses, capture participant results, and upload event images through the API.

### Participant

Participants can browse events and categories, update their own profile, enrol in an event by selecting a valid category, view their own enrolment status, and view their own race results.

The API enforces both authentication and role/ownership checks. A Participant cannot manage events, categories or results. An Organiser cannot use participant-only enrolment and personal-result endpoints.

## Technologies

- .NET 8 / ASP.NET Core Web API
- ASP.NET Core MVC
- Entity Framework Core Code First
- SQL Server
- Swagger / OpenAPI
- BCrypt password hashing
- xUnit and ASP.NET Core test tooling
- GitHub Actions
- Azure Blob Storage integration for Part 3 image uploads
- Dockerfile for the MVC application

## Setup and database

1. Install the .NET 8 SDK and SQL Server.
2. Update `src/RaceDay.Api/appsettings.json` with the SQL Server connection string.
3. From the repository root, run:

```bash
dotnet restore RaceDay.sln
dotnet ef database update --project src/RaceDay.Api --startup-project src/RaceDay.Api
dotnet run --project src/RaceDay.Api
```

4. Open Swagger at the URL printed by the API, normally `/swagger`.
5. Run the MVC client separately:

```bash
dotnet run --project src/RaceDay.Mvc
```

The SQL script in `docs/DatabaseScript.sql` is the Part 1 reference/seed script for SQL Server Management Studio. Its `GO` batch separators are on separate lines so the complete script executes cleanly from the beginning.

## API documentation

The complete endpoint table is in [`docs/API-Endpoint-Plan.md`](docs/API-Endpoint-Plan.md) and [`docs/API-Endpoint-Plan.pdf`](docs/API-Endpoint-Plan.pdf). It includes method, route, description, required role, request data, expected success response, and relevant `400`, `401`, `403`, `404`, `409`, and `500` failures.

Protected requests use the `X-Session-Token` header returned by login. The complete Swagger demonstration flow is: register, login, create an event as Organiser, create categories, enrol as Participant, view enrolments as the event owner, capture a result, and view personal results as the Participant.

## Build and tests

Run locally before every push:

```bash
dotnet build RaceDay.sln --configuration Release
dotnet test RaceDay.sln --configuration Release
```

The GitHub Actions workflow at [`.github/workflows/ci.yml`](.github/workflows/ci.yml) restores, builds, and tests every push and pull request. The current automated suite covers session creation/revocation, supported enrolment statuses, and role separation. Add further controller integration tests before final submission for registration/login, organiser event management, wrong-role rejection, and participant enrolment.

## CI/CD evidence

**Required personal evidence:** after pushing this repository to your GitHub account, open the successful green Actions run and save the screenshot as `docs/CI-CD-Screenshot.png`. Do not submit a locally generated image as a GitHub Actions screenshot. Then uncomment/add the image below:

```markdown
![Successful GitHub Actions build](docs/CI-CD-Screenshot.png)
```

## Video evidence

**Required personal evidence:** record the required unlisted YouTube video in your own voice. Demonstrate the running API, repository structure, ERD/database, authentication, roles, Swagger flow, unit tests, and green GitHub Actions run. Replace the line below with the real unlisted URL before submitting:

`YouTube video: PASTE-YOUR-UNLISTED-YOUTUBE-URL-HERE`

## Azure Blob Storage

Configure `AzureStorage__ConnectionString` and `AzureStorage__ContainerName` as environment variables or deployment secrets. The MVC application must send image uploads through `POST /api/uploads/event-image`; it must not communicate with Azure Blob Storage directly.

## Docker

The root `Dockerfile` publishes the MVC project. After installing Docker, build and run it with:

```bash
docker build -t raceday-mvc .
docker run --rm -p 8080:8080 \
  -e ApiBaseUrl=https://host.docker.internal:7001/ \
  raceday-mvc
```

## Final submission checklist

- [ ] Repository link submitted on ARC; source files are visible directly in GitHub.
- [ ] `/docs` contains ERD, endpoint plan, SQL script and evidence files.
- [ ] ERD and SQL match exactly.
- [ ] At least 20 meaningful commits made using the student’s own GitHub account.
- [ ] GitHub Actions green-build screenshot added to the README.
- [ ] Real unlisted YouTube video link added.
- [ ] SQL Server tables verified in SSMS.
- [ ] Swagger flow demonstrated successfully.
- [ ] All tests pass locally and in GitHub Actions.
