/* RaceDay Part 1 SQL Server script
   Demo password for all seeded users: Password123!
*/
CREATE DATABASE RaceDay;
GO

USE RaceDay;
GO

CREATE TABLE Users (
    Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Users PRIMARY KEY,
    FullName NVARCHAR(120) NOT NULL,
    Email NVARCHAR(255) NOT NULL CONSTRAINT UQ_Users_Email UNIQUE,
    PasswordHash NVARCHAR(255) NOT NULL,
    Role NVARCHAR(20) NOT NULL CONSTRAINT CK_Users_Role CHECK (Role IN ('Organiser', 'Participant'))
);
GO

CREATE TABLE Profiles (
    Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Profiles PRIMARY KEY,
    UserId INT NOT NULL CONSTRAINT UQ_Profiles_User UNIQUE,
    Phone NVARCHAR(30) NOT NULL,
    City NVARCHAR(100) NOT NULL,
    CONSTRAINT FK_Profiles_Users FOREIGN KEY (UserId) REFERENCES Users(Id)
);
GO

CREATE TABLE Events (
    Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Events PRIMARY KEY,
    Name NVARCHAR(160) NOT NULL,
    Description NVARCHAR(1000) NOT NULL,
    EventDate DATE NOT NULL,
    Location NVARCHAR(160) NOT NULL,
    DistanceKm DECIMAL(8,2) NOT NULL CONSTRAINT CK_Events_Distance CHECK (DistanceKm > 0),
    EventType NVARCHAR(20) NOT NULL CONSTRAINT CK_Events_Type CHECK (EventType IN ('Run', 'Walk', 'Cycle')),
    OrganiserId INT NOT NULL,
    CONSTRAINT FK_Events_Users_Organiser FOREIGN KEY (OrganiserId) REFERENCES Users(Id)
);
GO

CREATE TABLE Categories (
    Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Categories PRIMARY KEY,
    Name NVARCHAR(80) NOT NULL,
    EntryFee DECIMAL(10,2) NOT NULL CONSTRAINT DF_Categories_EntryFee DEFAULT (0),
    EventId INT NOT NULL,
    CONSTRAINT CK_Categories_EntryFee CHECK (EntryFee >= 0),
    CONSTRAINT FK_Categories_Events FOREIGN KEY (EventId) REFERENCES Events(Id)
);
GO

CREATE TABLE Enrolments (
    Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Enrolments PRIMARY KEY,
    ParticipantId INT NOT NULL,
    EventId INT NOT NULL,
    CategoryId INT NOT NULL,
    Status NVARCHAR(20) NOT NULL CONSTRAINT DF_Enrolments_Status DEFAULT ('Pending'),
    EnrolledAt DATETIME2 NOT NULL CONSTRAINT DF_Enrolments_EnrolledAt DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT CK_Enrolments_Status CHECK (Status IN ('Pending', 'Confirmed', 'Cancelled')),
    CONSTRAINT UQ_Enrolments_Participant_Event UNIQUE (ParticipantId, EventId),
    CONSTRAINT FK_Enrolments_Users_Participant FOREIGN KEY (ParticipantId) REFERENCES Users(Id),
    CONSTRAINT FK_Enrolments_Events FOREIGN KEY (EventId) REFERENCES Events(Id),
    CONSTRAINT FK_Enrolments_Categories FOREIGN KEY (CategoryId) REFERENCES Categories(Id)
);
GO

CREATE TABLE Results (
    Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Results PRIMARY KEY,
    EnrolmentId INT NOT NULL CONSTRAINT UQ_Results_Enrolment UNIQUE,
    EventId INT NOT NULL,
    ParticipantId INT NOT NULL,
    FinishTime TIME NOT NULL,
    Position INT NOT NULL CONSTRAINT CK_Results_Position CHECK (Position > 0),
    CONSTRAINT FK_Results_Enrolments FOREIGN KEY (EnrolmentId) REFERENCES Enrolments(Id),
    CONSTRAINT FK_Results_Events FOREIGN KEY (EventId) REFERENCES Events(Id),
    CONSTRAINT FK_Results_Users_Participant FOREIGN KEY (ParticipantId) REFERENCES Users(Id)
);
GO

INSERT INTO Users (FullName, Email, PasswordHash, Role) VALUES
('Amina Dlamini', 'amina@raceday.test', '$2a$11$zYQawNrzcv472ax0H.2Xn.YlLtBrxVTOBuIZ.pE6uMcMzGz7Vfp3m', 'Organiser'),
('Thabo Mokoena', 'thabo@raceday.test', '$2a$11$zYQawNrzcv472ax0H.2Xn.YlLtBrxVTOBuIZ.pE6uMcMzGz7Vfp3m', 'Organiser'),
('Lebo Naidoo', 'lebo@raceday.test', '$2a$11$zYQawNrzcv472ax0H.2Xn.YlLtBrxVTOBuIZ.pE6uMcMzGz7Vfp3m', 'Participant'),
('Sipho Ndlovu', 'sipho@raceday.test', '$2a$11$zYQawNrzcv472ax0H.2Xn.YlLtBrxVTOBuIZ.pE6uMcMzGz7Vfp3m', 'Participant');
GO

INSERT INTO Profiles (UserId, Phone, City) VALUES
(1, '0710000001', 'Cape Town'),
(2, '0720000002', 'Johannesburg'),
(3, '0730000003', 'Durban'),
(4, '0740000004', 'Pretoria');
GO

INSERT INTO Events (Name, Description, EventDate, Location, DistanceKm, EventType, OrganiserId) VALUES
('Cape Town City Tour', 'Road cycling challenge', '2026-11-15', 'Cape Town', 109.00, 'Cycle', 1),
('Soweto Marathon', 'Community marathon', '2026-10-25', 'Johannesburg', 42.20, 'Run', 2),
('Two Oceans Walk', 'Scenic walking event', '2027-03-28', 'Cape Town', 10.00, 'Walk', 1);
GO

INSERT INTO Categories (Name, EntryFee, EventId) VALUES
('Open', 250.00, 1), ('Junior', 100.00, 1),
('10km', 180.00, 2), ('42km', 350.00, 2),
('Family', 80.00, 3), ('Senior', 60.00, 3);
GO

INSERT INTO Enrolments (ParticipantId, EventId, CategoryId, Status) VALUES
(3, 1, 1, 'Confirmed'),
(4, 2, 3, 'Pending');
GO
