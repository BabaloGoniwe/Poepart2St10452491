# RaceDay Part 2 API Endpoint Plan

All protected requests send `X-Session-Token`. `401` means no valid session; `403` means the authenticated user has the wrong role or does not own the resource; `404` means the resource does not exist; `409` means a duplicate/conflicting operation; `400` means invalid input.

| HTTP method | Route | Description | Role required | Request body / parameters | Expected response |
|---|---|---|---|---|---|
| POST | `/api/auth/register` | Create an account and hash the password | Public | `fullName`, `email`, `password`, `role` | `201` user; `400` invalid role/data; `409` duplicate email |
| POST | `/api/auth/login` | Verify credentials and create a session | Public | `email`, `password` | `200` token/user; `401` invalid credentials |
| POST | `/api/auth/logout` | Revoke the current session | Authenticated | Header token | `204`; safe if token is already absent |
| GET | `/api/profile/me` | View the logged-in user’s own profile | Authenticated | None | `200` profile; `401` unauthenticated |
| PUT | `/api/profile/me` | Update only the logged-in user’s profile | Authenticated | `fullName`, `phone`, `city` | `200` profile; `401` unauthenticated; `400` invalid data |
| GET | `/api/events` | Browse all events and categories | Public | None | `200` event list |
| GET | `/api/events/{id}` | View one event | Public | Route `id` | `200` event; `404` not found |
| GET | `/api/events/mine` | View events owned by the organiser | Organiser | None | `200` event list; `401`; `403` participant |
| POST | `/api/events` | Create an event owned by the session organiser | Organiser | Name, description, date, location, distance, type | `201` event; `401`; `403`; `400` invalid data |
| PUT | `/api/events/{id}` | Update an owned event | Organiser owner | Event fields; route `id` | `200` event; `401`; `403` not owner; `404` |
| DELETE | `/api/events/{id}` | Delete an owned event | Organiser owner | Route `id` | `204`; `401`; `403`; `404` |
| GET | `/api/events/{eventId}/categories` | Browse categories for an event | Public | Route `eventId` | `200` category list; `404` event not found |
| POST | `/api/events/{eventId}/categories` | Add a category to an owned event | Organiser owner | `name`, `entryFee`; route `eventId` | `201` category; `400`; `401`; `403`; `404` |
| PUT | `/api/categories/{id}` | Update a category on an owned event | Organiser owner | `name`, `entryFee`; route `id` | `200` category; `400`; `401`; `403`; `404` |
| DELETE | `/api/categories/{id}` | Delete a category on an owned event | Organiser owner | Route `id` | `204`; `401`; `403`; `404` |
| POST | `/api/enrolments` | Enter an event using a valid category | Participant | `eventId`, `categoryId` | `201` enrolment; `400`; `401`; `403`; `404`; `409` duplicate |
| GET | `/api/enrolments/mine` | View own enrolments | Participant | None | `200` enrolment list; `401`; `403` organiser |
| GET | `/api/enrolments/event/{eventId}` | View enrolments for an owned event | Organiser owner | Route `eventId` | `200` enrolment list; `401`; `403`; `404` |
| PUT | `/api/enrolments/{id}/status` | Confirm or cancel an enrolment | Organiser owner | `status` = Pending/Confirmed/Cancelled | `200` enrolment; `400`; `401`; `403`; `404` |
| POST | `/api/results` | Capture a result for an enrolled participant | Organiser owner | `enrolmentId`, `finishTime`, `position` | `201` result; `401`; `403`; `404`; `409` result exists |
| GET | `/api/results/mine` | View personal results | Participant | None | `200` result list; `401`; `403` organiser |
| GET | `/api/results/event/{eventId}` | View results for an owned event | Organiser owner | Route `eventId` | `200` result list; `401`; `403`; `404` |
| POST | `/api/uploads/event-image` | Upload an event image for Part 3 | Organiser | Multipart image file | `200` URL; `400` invalid file; `401`; `403`; `500` storage failure |

## Planned-to-code alignment

The implementation must match this table. If a route or request shape changes, update this document and explain the reason in the README before committing the code change.
