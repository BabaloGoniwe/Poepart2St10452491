# RaceDay Entity Relationship Diagram

The ERD below is the authoritative Part 1 design. It matches `DatabaseScript.sql` exactly, including event descriptions, enrolment status, and the one-result-per-enrolment relationship.

```mermaid
erDiagram
    USERS ||--|| PROFILES : has
    USERS ||--o{ EVENTS : organises
    USERS ||--o{ ENROLMENTS : makes
    EVENTS ||--o{ CATEGORIES : contains
    EVENTS ||--o{ ENROLMENTS : receives
    CATEGORIES ||--o{ ENROLMENTS : selected_for
    ENROLMENTS ||--o| RESULTS : produces

    USERS {
        int Id PK
        nvarchar FullName
        nvarchar Email UK
        nvarchar PasswordHash
        nvarchar Role
    }
    PROFILES {
        int Id PK
        int UserId FK
        nvarchar Phone
        nvarchar City
    }
    EVENTS {
        int Id PK
        nvarchar Name
        nvarchar Description
        date EventDate
        nvarchar Location
        decimal DistanceKm
        nvarchar EventType
        int OrganiserId FK
    }
    CATEGORIES {
        int Id PK
        nvarchar Name
        decimal EntryFee
        int EventId FK
    }
    ENROLMENTS {
        int Id PK
        int ParticipantId FK
        int EventId FK
        int CategoryId FK
        nvarchar Status
        datetime2 EnrolledAt
    }
    RESULTS {
        int Id PK
        int EnrolmentId FK
        int EventId FK
        int ParticipantId FK
        time FinishTime
        int Position
    }
```

## Relationship and constraint notes

- Every `USER` has one `PROFILE`; `Profiles.UserId` is unique.
- One Organiser can manage many `EVENTS`; `Events.OrganiserId` is a foreign key.
- Each `EVENT` has many `CATEGORIES`.
- A Participant can make many `ENROLMENTS`; an event/category combination is selected by the enrolment.
- `Enrolments.Status` is restricted to `Pending`, `Confirmed`, or `Cancelled`.
- An `ENROLMENT` can have zero or one `RESULT`; `Results.EnrolmentId` is unique.
- `Results.EventId` and `Results.ParticipantId` are retained for reporting and are populated from the selected enrolment by the API.

Render this Markdown diagram to `ERD.png` and submit both files in `/docs`.
