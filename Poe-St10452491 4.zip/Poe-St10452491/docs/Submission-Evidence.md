# RaceDay Submission Evidence

This file records evidence that must be produced from the student’s own GitHub account and voice recording. It intentionally does not fabricate external evidence.

## GitHub repository

- Repository link: `PASTE-YOUR-GITHUB-REPOSITORY-URL-HERE`
- Required branch/subfolder: Part 1 / Part 2 as instructed by the lecturer.
- Confirm `/docs`, `.github/workflows`, `src`, and `tests` are visible directly in GitHub.

## 20 meaningful commits

Use the student’s own GitHub identity and commit progressively. Suggested meaningful stages are:

1. Create solution
2. Add API project
3. Add contracts project
4. Add test project
5. Add entity models
6. Add DbContext
7. Configure SQL Server
8. Add EF migration
9. Add registration
10. Add password hashing
11. Add login sessions
12. Add profile endpoints
13. Add event browsing
14. Add organiser event management
15. Add category management
16. Add participant enrolments
17. Add enrolment status management
18. Add results
19. Add Swagger documentation
20. Add tests and CI workflow

Do not create meaningless commits at the end; each commit must contain the corresponding code or documentation change.

## CI/CD screenshot

After pushing, open the successful green GitHub Actions run for `.github/workflows/ci.yml`, capture it, save it as `docs/CI-CD-Screenshot.png`, and reference it from the README.

## Video

Record an unlisted YouTube video in the student’s own voice showing the repository structure, ERD, SQL/EF Core, Swagger registration/login, role restrictions, enrolment flow, results, tests, and the green GitHub Actions run. Paste the real URL in the README.
